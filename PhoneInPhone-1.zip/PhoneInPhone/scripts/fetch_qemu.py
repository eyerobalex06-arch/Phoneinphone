#!/usr/bin/env python3
"""Pulls prebuilt aarch64 QEMU + dependencies from the Termux repo and lays them out for the app:
   jniLibs/arm64-v8a/libqemu.so, libqemuimg.so   (executables, must live in the native lib dir)
   assets/qemu-lib/*                              (shared libs, loaded via LD_LIBRARY_PATH)
   assets/qemu-share/*                            (BIOS / firmware files, passed with -L)
Run from the repo root. Needs: python3, dpkg-deb (preinstalled on GitHub Ubuntu runners)."""
import os, re, shutil, subprocess, sys, tempfile, urllib.request

BASE = "https://packages.termux.dev/apt/termux-main/"
INDEX = BASE + "dists/stable/main/binary-aarch64/Packages"
ROOTS = ["qemu-system-x86-64", "qemu-utils"]
SKIP = ("python", "termux-")
PREFIX = "data/data/com.termux/files/usr"

def get(url):
    with urllib.request.urlopen(url) as r:
        return r.read()

def parse(text):
    pk = {}
    for blk in text.split("\n\n"):
        d = {}
        for line in blk.splitlines():
            if not line.startswith(" ") and ": " in line:
                k, v = line.split(": ", 1)
                d[k] = v
        if "Package" in d:
            pk[d["Package"]] = d
    return pk

def deps(d):
    out = []
    for part in d.get("Depends", "").split(","):
        name = part.split("|")[0].strip().split(" ")[0]
        if name:
            out.append(name)
    return out

def main():
    pk = parse(get(INDEX).decode())
    todo, seen = list(ROOTS), []
    while todo:
        n = todo.pop()
        if n in seen or n.startswith(SKIP):
            continue
        if n not in pk:
            sys.exit(f"package not found in Termux repo: {n}")
        seen.append(n)
        todo += deps(pk[n])
    print("packages:", ", ".join(sorted(seen)))

    tmp = tempfile.mkdtemp()
    root = os.path.join(tmp, "root")
    for n in seen:
        deb = os.path.join(tmp, n + ".deb")
        with open(deb, "wb") as f:
            f.write(get(BASE + pk[n]["Filename"]))
        subprocess.check_call(["dpkg-deb", "-x", deb, root])
    usr = os.path.join(root, PREFIX)

    jni = "app/src/main/jniLibs/arm64-v8a"
    lib = "app/src/main/assets/qemu-lib"
    share = "app/src/main/assets/qemu-share"
    for d in (jni, lib, share):
        shutil.rmtree(d, ignore_errors=True)
        os.makedirs(d)

    shutil.copy2(os.path.join(usr, "bin/qemu-system-x86_64"), os.path.join(jni, "libqemu.so"))
    shutil.copy2(os.path.join(usr, "bin/qemu-img"), os.path.join(jni, "libqemuimg.so"))
    ulib = os.path.join(usr, "lib")
    for f in os.listdir(ulib):
        p = os.path.join(ulib, f)
        if re.search(r"\.so(\.|$)", f) and os.path.isfile(p):   # isfile follows symlinks
            shutil.copy2(p, os.path.join(lib, f), follow_symlinks=True)
    shutil.copytree(os.path.join(usr, "share/qemu"), share, dirs_exist_ok=True)
    print("done: qemu + %d libs bundled" % len(os.listdir(lib)))

if __name__ == "__main__":
    main()
