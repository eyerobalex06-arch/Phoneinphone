package com.example.phoneinphone

import android.content.Context
import android.graphics.*
import android.text.InputType
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import java.io.*
import java.net.Socket
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/** Minimal RFB (VNC) client: no auth, raw encoding. Talks to QEMU's built-in VNC server on localhost. */
class VncView(ctx: Context) : View(ctx) {
    private var bmp: Bitmap? = null
    private val lock = Any()
    private val sender = Executors.newSingleThreadExecutor()
    @Volatile private var out: DataOutputStream? = null
    private var fbW = 0
    private var fbH = 0
    private var scale = 1f
    private var offX = 0f
    private var offY = 0f
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    var status: (String) -> Unit = {}

    init { isFocusable = true; isFocusableInTouchMode = true }

    fun connect() {
        thread {
            var connected = false
            for (attempt in 0 until 90) {
                try {
                    session { connected = true; status("Connected") }
                } catch (e: Exception) {
                    if (connected || !Qemu.running) {
                        status("Disconnected: ${e.message}\n${Qemu.logTail()}")
                        return@thread
                    }
                    Thread.sleep(1000)
                }
            }
            status("Could not connect to VM display\n${Qemu.logTail()}")
        }
    }

    private fun session(onReady: () -> Unit) {
        val s = Socket("127.0.0.1", 5901)
        val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 1 shl 16))
        val o = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
        inp.readFully(ByteArray(12))
        o.write("RFB 003.008\n".toByteArray()); o.flush()
        val n = inp.readUnsignedByte()
        if (n == 0) throw IOException("server refused")
        inp.readFully(ByteArray(n))
        o.writeByte(1); o.flush()                       // security type: None
        if (inp.readInt() != 0) throw IOException("auth failed")
        o.writeByte(1); o.flush()                       // shared flag
        val w = inp.readUnsignedShort(); val h = inp.readUnsignedShort()
        inp.readFully(ByteArray(16))
        inp.readFully(ByteArray(inp.readInt()))
        resize(w, h)
        // SetPixelFormat: 32bpp little-endian BGRX
        o.writeByte(0); o.write(ByteArray(3))
        o.writeByte(32); o.writeByte(24); o.writeByte(0); o.writeByte(1)
        o.writeShort(255); o.writeShort(255); o.writeShort(255)
        o.writeByte(16); o.writeByte(8); o.writeByte(0); o.write(ByteArray(3))
        // SetEncodings: Raw + DesktopSize
        o.writeByte(2); o.writeByte(0); o.writeShort(2); o.writeInt(0); o.writeInt(-223)
        o.flush()
        out = o
        onReady()
        request(o, false)
        while (true) {
            when (inp.readUnsignedByte()) {
                0 -> {
                    inp.readByte()
                    var resized = false
                    repeat(inp.readUnsignedShort()) {
                        val x = inp.readUnsignedShort(); val y = inp.readUnsignedShort()
                        val rw = inp.readUnsignedShort(); val rh = inp.readUnsignedShort()
                        when (val enc = inp.readInt()) {
                            0 -> readRaw(inp, x, y, rw, rh)
                            -223 -> { resize(rw, rh); resized = true }
                            else -> throw IOException("unsupported encoding $enc")
                        }
                    }
                    postInvalidate()
                    request(o, !resized)
                }
                1 -> { inp.readByte(); inp.readUnsignedShort(); inp.readFully(ByteArray(inp.readUnsignedShort() * 6)) }
                2 -> {}
                3 -> { inp.readFully(ByteArray(3)); inp.readFully(ByteArray(inp.readInt())) }
                else -> throw IOException("bad server message")
            }
        }
    }

    private fun request(o: DataOutputStream, incremental: Boolean) = synchronized(o) {
        o.writeByte(3); o.writeByte(if (incremental) 1 else 0)
        o.writeShort(0); o.writeShort(0); o.writeShort(fbW); o.writeShort(fbH); o.flush()
    }

    private fun resize(w: Int, h: Int) = synchronized(lock) {
        fbW = w; fbH = h
        bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    }

    private fun readRaw(inp: DataInputStream, x: Int, y: Int, rw: Int, rh: Int) {
        val row = ByteArray(rw * 4)
        val px = IntArray(rw * rh)
        for (r in 0 until rh) {
            inp.readFully(row)
            for (i in 0 until rw) {
                val b = row[i * 4].toInt() and 255
                val g = row[i * 4 + 1].toInt() and 255
                val rr = row[i * 4 + 2].toInt() and 255
                px[r * rw + i] = (0xFF shl 24) or (rr shl 16) or (g shl 8) or b
            }
        }
        synchronized(lock) {
            val b = bmp ?: return
            if (x + rw <= b.width && y + rh <= b.height) b.setPixels(px, 0, rw, x, y, rw, rh)
        }
    }

    private fun send(block: (DataOutputStream) -> Unit) {
        val o = out ?: return
        sender.execute { try { synchronized(o) { block(o); o.flush() } } catch (_: Exception) {} }
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.BLACK)
        synchronized(lock) {
            val b = bmp ?: return
            scale = minOf(width / b.width.toFloat(), height / b.height.toFloat())
            offX = (width - b.width * scale) / 2f
            offY = (height - b.height * scale) / 2f
            val dst = RectF(offX, offY, offX + b.width * scale, offY + b.height * scale)
            c.drawBitmap(b, null, dst, paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = ((e.x - offX) / scale).toInt().coerceIn(0, maxOf(fbW - 1, 0))
        val y = ((e.y - offY) / scale).toInt().coerceIn(0, maxOf(fbH - 1, 0))
        val buttons = if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) 0 else 1
        send { it.writeByte(5); it.writeByte(buttons); it.writeShort(x); it.writeShort(y) }
        return true
    }

    private fun keysym(e: KeyEvent): Int = when (e.keyCode) {
        KeyEvent.KEYCODE_ENTER -> 0xFF0D
        KeyEvent.KEYCODE_DEL -> 0xFF08
        KeyEvent.KEYCODE_ESCAPE -> 0xFF1B
        KeyEvent.KEYCODE_TAB -> 0xFF09
        KeyEvent.KEYCODE_DPAD_LEFT -> 0xFF51
        KeyEvent.KEYCODE_DPAD_UP -> 0xFF52
        KeyEvent.KEYCODE_DPAD_RIGHT -> 0xFF53
        KeyEvent.KEYCODE_DPAD_DOWN -> 0xFF54
        else -> e.unicodeChar
    }

    private fun key(e: KeyEvent, down: Boolean): Boolean {
        val sym = keysym(e)
        if (sym == 0) return false
        send { it.writeByte(4); it.writeByte(if (down) 1 else 0); it.writeShort(0); it.writeInt(sym) }
        return true
    }

    override fun onKeyDown(k: Int, e: KeyEvent) = key(e, true) || super.onKeyDown(k, e)
    override fun onKeyUp(k: Int, e: KeyEvent) = key(e, false) || super.onKeyUp(k, e)
    override fun onCheckIsTextEditor() = true
    override fun onCreateInputConnection(a: EditorInfo): InputConnection {
        a.inputType = InputType.TYPE_NULL
        return BaseInputConnection(this, false)
    }
}
