package com.example.phoneinphone

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager

/** Keeps the process (and QEMU) alive while the app is in the background. */
class VmService : Service() {
    private var wl: PowerManager.WakeLock? = null
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vm", "Virtual phone", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "vm")
            .setContentTitle("Android VM running")
            .setContentText("Open the app and tap Save & Exit when done")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (wl == null) {
            wl = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "phoneinphone:vm").apply { acquire() }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() { wl?.release(); super.onDestroy() }
}
