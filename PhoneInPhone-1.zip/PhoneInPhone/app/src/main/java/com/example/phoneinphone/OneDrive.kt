package com.example.phoneinphone

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** OneDrive sync via Microsoft Graph, using device-code sign-in (no SDK, no redirect URI needed). */
class OneDrive(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("od", 0)
    private val auth = "https://login.microsoftonline.com/common/oauth2/v2.0"
    private val graph = "https://graph.microsoft.com/v1.0/me/drive"
    private val remote = "root:/AndroidVM/android11.qcow2"
    private var access: String? = null
    private var expires = 0L

    var clientId: String
        get() = prefs.getString("cid", "") ?: ""
        set(v) { prefs.edit().putString("cid", v.trim()).apply() }
    val signedIn: Boolean get() = prefs.getString("rt", null) != null

    private fun http(method: String, url: String, form: Map<String, String>? = null,
                     json: String? = null, bearer: Boolean = false): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 30000; c.readTimeout = 60000
        if (bearer) c.setRequestProperty("Authorization", "Bearer ${token()}")
        val body = when {
            form != null -> form.entries.joinToString("&") { "${it.key}=${URLEncoder.encode(it.value, "UTF-8")}" }
                .also { c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded") }
            json != null -> json.also { c.setRequestProperty("Content-Type", "application/json") }
            else -> null
        }
        if (body != null) { c.doOutput = true; c.outputStream.use { it.write(body.toByteArray()) } }
        val code = c.responseCode
        val text = (if (code >= 400) c.errorStream else c.inputStream)?.bufferedReader()?.readText() ?: ""
        return code to text
    }

    // ---- sign-in ----
    fun beginLogin(): JSONObject {
        val (code, body) = http("POST", "$auth/devicecode",
            form = mapOf("client_id" to clientId, "scope" to "Files.ReadWrite offline_access"))
        if (code != 200) throw IOException("Sign-in failed: $body")
        return JSONObject(body)
    }

    fun finishLogin(d: JSONObject) {
        val end = System.currentTimeMillis() + d.getLong("expires_in") * 1000
        val wait = d.optLong("interval", 5) * 1000
        while (System.currentTimeMillis() < end) {
            Thread.sleep(wait)
            val (code, body) = http("POST", "$auth/token", form = mapOf(
                "grant_type" to "urn:ietf:params:oauth:grant-type:device_code",
                "client_id" to clientId, "device_code" to d.getString("device_code")))
            val t = JSONObject(body)
            if (code == 200) { store(t); return }
            val err = t.optString("error")
            if (err != "authorization_pending" && err != "slow_down") throw IOException(t.optString("error_description", err))
        }
        throw IOException("Sign-in timed out")
    }

    private fun store(t: JSONObject) {
        access = t.getString("access_token")
        expires = System.currentTimeMillis() + t.getLong("expires_in") * 1000 - 60000
        t.optString("refresh_token").takeIf { it.isNotEmpty() }?.let { prefs.edit().putString("rt", it).apply() }
    }

    private fun token(): String {
        if (access != null && System.currentTimeMillis() < expires) return access!!
        val rt = prefs.getString("rt", null) ?: throw IOException("Not signed in")
        val (code, body) = http("POST", "$auth/token", form = mapOf(
            "grant_type" to "refresh_token", "client_id" to clientId,
            "refresh_token" to rt, "scope" to "Files.ReadWrite offline_access"))
        if (code != 200) throw IOException("Token refresh failed: $body")
        store(JSONObject(body))
        return access!!
    }

    // ---- sync ----
    private fun info(): JSONObject? {
        val (code, body) = http("GET", "$graph/$remote", bearer = true)
        if (code == 404) return null
        if (code != 200) throw IOException("OneDrive error $code: $body")
        return JSONObject(body)
    }

    /** True when OneDrive holds a newer copy than the one this phone last synced (or there is no local disk). */
    fun needsDownload(): Boolean {
        val i = info() ?: return false
        return !Qemu.disk.exists() || i.optString("eTag") != prefs.getString("etag", null)
    }

    fun download(dest: File, progress: (Long, Long) -> Unit) {
        val i = info() ?: throw IOException("Nothing on OneDrive yet")
        val total = i.getLong("size")
        val c = URL(i.getString("@microsoft.graph.downloadUrl")).openConnection() as HttpURLConnection
        val part = File(dest.path + ".part")
        c.inputStream.use { ins ->
            part.outputStream().use { o ->
                val buf = ByteArray(1 shl 20); var done = 0L
                while (true) {
                    val n = ins.read(buf); if (n < 0) break
                    o.write(buf, 0, n); done += n; progress(done, total)
                }
            }
        }
        dest.delete(); part.renameTo(dest)
        prefs.edit().putString("etag", i.optString("eTag")).apply()
    }

    fun upload(file: File, progress: (Long, Long) -> Unit) {
        val (code, body) = http("POST", "$graph/$remote:/createUploadSession",
            json = """{"item":{"@microsoft.graph.conflictBehavior":"replace"}}""", bearer = true)
        if (code != 200) throw IOException("Upload session failed: $body")
        val url = JSONObject(body).getString("uploadUrl")
        val total = file.length()
        val chunk = 32 * 320 * 1024                     // must be a multiple of 320 KiB
        val buf = ByteArray(chunk)
        var last = ""
        RandomAccessFile(file, "r").use { raf ->
            var pos = 0L
            while (pos < total) {
                val len = minOf(chunk.toLong(), total - pos).toInt()
                raf.seek(pos); raf.readFully(buf, 0, len)
                var ok = false; var tries = 0
                while (!ok) {
                    try {
                        val c = URL(url).openConnection() as HttpURLConnection
                        c.requestMethod = "PUT"; c.doOutput = true
                        c.setFixedLengthStreamingMode(len)
                        c.setRequestProperty("Content-Range", "bytes $pos-${pos + len - 1}/$total")
                        c.outputStream.use { it.write(buf, 0, len) }
                        val rc = c.responseCode
                        val txt = (if (rc >= 400) c.errorStream else c.inputStream)?.bufferedReader()?.readText() ?: ""
                        if (rc != 200 && rc != 201 && rc != 202) throw IOException("chunk failed $rc: $txt")
                        last = txt; ok = true
                    } catch (e: IOException) { if (++tries >= 4) throw e; Thread.sleep(2000L * tries) }
                }
                pos += len; progress(pos, total)
            }
        }
        runCatching { JSONObject(last).optString("eTag") }.getOrNull()
            ?.takeIf { it.isNotEmpty() }?.let { prefs.edit().putString("etag", it).apply() }
    }
}
