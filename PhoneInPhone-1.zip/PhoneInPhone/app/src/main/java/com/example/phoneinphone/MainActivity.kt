package com.example.phoneinphone

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.InputMethodManager
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var vnc: VncView
    private lateinit var status: TextView
    private lateinit var clientId: EditText
    private lateinit var od: OneDrive
    private val prefs by lazy { getSharedPreferences("vm", 0) }

    private fun ui(s: String) = runOnUiThread { status.text = s }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Qemu.ctx = applicationContext
        od = OneDrive(this)
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        vnc = VncView(this).apply { status = { ui(it) } }
        status = TextView(this).apply { setPadding(24, 16, 24, 8); text = "Ready" }
        clientId = EditText(this).apply { hint = "Azure client ID (for OneDrive)"; setText(od.clientId); setSingleLine() }

        val row1 = LinearLayout(this).apply {
            addView(btn("Pick ISO") { pickIso() }); addView(btn("Sign in") { signIn() }); addView(btn("Keyboard") { keyboard() })
        }
        val row2 = LinearLayout(this).apply {
            addView(btn("Start") { startVm() }); addView(btn("Save & Exit") { saveExit() })
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(status); addView(clientId); addView(row1); addView(row2)
            addView(vnc, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        })
    }

    override fun onBackPressed() { moveTaskToBack(true) }   // VM keeps running in the service

    private fun keyboard() {
        vnc.requestFocus()
        getSystemService(InputMethodManager::class.java).showSoftInput(vnc, 0)
    }

    private fun pickIso() = startActivityForResult(
        Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 7)

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        val uri: Uri = data?.data ?: return
        if (req != 7 || res != RESULT_OK) return
        thread {
            try {
                ui("Copying ISO…")
                contentResolver.openInputStream(uri)!!.use { i -> Qemu.iso.outputStream().use { o -> i.copyTo(o) } }
                ui("ISO ready. Tap Start.")
            } catch (e: Exception) { ui("ISO copy failed: ${e.message}") }
        }
    }

    private fun signIn() {
        od.clientId = clientId.text.toString()
        if (od.clientId.isEmpty()) { ui("Enter your Azure client ID first (see README)"); return }
        thread {
            try {
                val d = od.beginLogin()
                val uri = d.getString("verification_uri"); val code = d.getString("user_code")
                runOnUiThread {
                    getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("code", code))
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)))
                }
                ui("Enter code $code at $uri (code copied)")
                od.finishLogin(d)
                ui("Signed in to OneDrive")
            } catch (e: Exception) { ui("Sign-in error: ${e.message}") }
        }
    }

    private fun startVm() = thread {
        try {
            if (Qemu.running) { ui("VM already running"); return@thread }
            ui("Preparing…"); Qemu.prepare()
            if (od.signedIn && od.needsDownload()) {
                od.download(Qemu.disk) { p, t -> ui("Downloading from OneDrive ${p * 100 / t}%") }
                prefs.edit().putBoolean("snap", true).putBoolean("installed", true).apply()
            }
            var resume = prefs.getBoolean("snap", false) && Qemu.disk.exists()
            if (!Qemu.disk.exists()) {
                if (!Qemu.iso.exists()) { ui("Pick a Bliss OS 11 ISO first"); return@thread }
                Qemu.createDisk(); resume = false
            }
            startForegroundService(Intent(this, VmService::class.java))
            Qemu.start(resume, prefs.getBoolean("installed", false))
            ui(if (resume) "Restoring your saved session…" else "Booting… first boot can take minutes")
            vnc.connect()
        } catch (e: Exception) { ui("Start failed: ${e.message}") }
    }

    private fun saveExit() = thread {
        try {
            if (!Qemu.running) { ui("VM is not running"); return@thread }
            ui("Saving VM state… (can take a minute)")
            Qemu.saveAndQuit()
            prefs.edit().putBoolean("snap", true).putBoolean("installed", true).apply()
            if (od.signedIn) {
                od.upload(Qemu.disk) { p, t -> ui("Uploading to OneDrive ${p * 100 / t}%") }
                ui("Saved to OneDrive. Safe to close.")
            } else ui("Saved on this phone only (not signed in to OneDrive).")
            stopService(Intent(this, VmService::class.java))
        } catch (e: Exception) { ui("Save failed: ${e.message}") }
    }
}
