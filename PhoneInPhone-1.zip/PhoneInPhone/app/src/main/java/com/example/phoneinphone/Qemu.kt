package com.example.phoneinphone

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.Socket
import java.util.concurrent.TimeUnit

/** Runs the bundled QEMU binary and talks to it over QMP to save/restore the whole VM state. */
object Qemu {
    lateinit var ctx: Context
    private var proc: Process? = null

    val vmDir: File get() = File(ctx.filesDir, "vm").also { it.mkdirs() }
    val disk: File get() = File(vmDir, "android11.qcow2")
    val iso: File get() = File(vmDir, "install.iso")
    private val log: File get() = File(vmDir, "qemu.log")
    private val libDir: File get() = File(ctx.filesDir, "qemu-lib")
    private val shareDir: File get() = File(ctx.filesDir, "qemu-share")
    private val nat: String get() = ctx.applicationInfo.nativeLibraryDir
    val running: Boolean get() = proc?.isAlive == true

    fun logTail(): String = try { log.readLines().takeLast(6).joinToString("\n") } catch (e: Exception) { "" }

    /** Copies bundled firmware + shared libraries out of the APK on first run. */
    fun prepare() {
        val marker = File(ctx.filesDir, "assets-v1")
        if (marker.exists()) return
        copyAssets("qemu-lib", libDir)
        copyAssets("qemu-share", shareDir)
        marker.writeText("ok")
    }

    private fun copyAssets(src: String, dst: File) {
        dst.mkdirs()
        for (n in ctx.assets.list(src) ?: return) {
            val sub = "$src/$n"
            val kids = ctx.assets.list(sub)
            if (kids != null && kids.isNotEmpty()) copyAssets(sub, File(dst, n))
            else ctx.assets.open(sub).use { i -> File(dst, n).outputStream().use { o -> i.copyTo(o) } }
        }
    }

    private fun env(pb: ProcessBuilder) = pb.apply {
        environment()["LD_LIBRARY_PATH"] = libDir.path
        redirectErrorStream(true)
    }

    fun createDisk() {
        val p = env(ProcessBuilder("$nat/libqemuimg.so", "create", "-f", "qcow2", disk.path, "24G")).start()
        val out = p.inputStream.bufferedReader().readText()
        if (p.waitFor() != 0) throw IOException("qemu-img failed: $out")
    }

    fun start(resume: Boolean, installed: Boolean) {
        val cmd = mutableListOf(
            "$nat/libqemu.so", "-L", shareDir.path,
            "-machine", "q35", "-cpu", "max", "-smp", "4", "-m", "3072",
            "-accel", "tcg,thread=multi",
            "-drive", "file=${disk.path},if=virtio,format=qcow2",
            "-device", "virtio-vga", "-device", "qemu-xhci",
            "-device", "usb-tablet", "-device", "usb-kbd",
            "-netdev", "user,id=n0", "-device", "virtio-net-pci,netdev=n0",
            "-vnc", "127.0.0.1:1",
            "-qmp", "tcp:127.0.0.1:4444,server,nowait"
        )
        // Keep the device layout identical between sessions, otherwise -loadvm refuses to restore.
        if (iso.exists()) cmd += listOf("-cdrom", iso.path)
        cmd += listOf("-boot", if (installed || !iso.exists()) "order=c" else "order=d")
        if (resume) cmd += listOf("-loadvm", "session")
        proc = env(ProcessBuilder(cmd)).redirectOutput(log).start()
    }

    /** Freezes the VM, writes RAM+CPU+disk state into the qcow2 ("savevm"), then quits QEMU. */
    fun saveAndQuit() {
        Socket("127.0.0.1", 4444).use { s ->
            s.soTimeout = 15 * 60 * 1000
            val r = s.getInputStream().bufferedReader()
            val w = s.getOutputStream().bufferedWriter()
            r.readLine() // greeting
            fun cmd(j: String): String {
                w.write(j + "\n"); w.flush()
                while (true) {
                    val l = r.readLine() ?: return ""
                    if (l.contains("\"return\"") || l.contains("\"error\"")) return l
                }
            }
            cmd("""{"execute":"qmp_capabilities"}""")
            val res = cmd("""{"execute":"human-monitor-command","arguments":{"command-line":"savevm session"}}""")
            if (res.replace(" ", "") != """{"return":""}""") throw IOException("savevm failed: $res")
            w.write("""{"execute":"quit"}""" + "\n"); w.flush()
        }
        proc?.waitFor(60, TimeUnit.SECONDS)
        proc?.destroyForcibly()
    }
}
