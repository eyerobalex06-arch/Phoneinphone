# PhoneInPhone

An Android app that runs Android 11 (Bliss OS 11, x86_64) inside QEMU on your phone, shows it
over a built-in VNC view, and saves the *entire* VM state (disk + RAM + CPU) to OneDrive when you
tap **Save & Exit**. Next launch downloads the newest save and resumes exactly where you left off.

STATUS: written but never compiled or run by its author. Expect to fix a few build/runtime errors.
Run speed: pure software emulation (TCG), x86 on ARM. It will be slow.

## 1. Register a free OneDrive app (5 min, on any browser)
1. portal.azure.com -> Microsoft Entra ID -> App registrations -> New registration.
2. Supported account types: "Any organizational directory and personal Microsoft accounts".
3. After creating: Authentication -> Advanced settings -> "Allow public client flows" = Yes.
4. API permissions -> Add -> Microsoft Graph -> Delegated -> `Files.ReadWrite` (and `offline_access`).
5. Copy the "Application (client) ID". You paste it into the app.

## 2. Build the APK (no Android Studio needed)
1. Create a new GitHub repo and upload everything in this folder (keep the folder structure,
   including `.github/workflows/build.yml`). Easiest from a computer: `git push`.
2. Repo -> Actions -> "Build APK" -> run it. It downloads QEMU from the Termux repo, compiles the app.
3. When green, open the run -> Artifacts -> download `PhoneInPhone-debug`, unzip, install the APK.
   (Allow "Install unknown apps".)
If the build fails, copy the red error text from the Actions log and send it to me.

## 3. Use it
1. Download the Bliss OS 11 x86_64 ISO (blissos.org). In the app tap **Pick ISO**.
2. Paste your client ID, tap **Sign in**, enter the code on the Microsoft page.
3. Tap **Start**. First boot = installer. Install Bliss to the virtual disk (virtio disk, 24 GB).
   Touch = mouse. **Keyboard** button opens the on-screen keyboard.
4. Tap **Save & Exit** when done. The state uploads to OneDrive/AndroidVM/android11.qcow2.
5. Next time, **Start** restores the saved session. (Don't delete the ISO: the virtual
   hardware must stay identical for the restore to work.)

## Known limits
- Upload is the whole disk file (several GB) each time: use Wi-Fi.
- If the app is force-killed, the last save is whatever you saved last.
- Refresh token is stored in plain app prefs (fine for personal use).
- Software emulation only; no Google apps/Play Store in Bliss by default.
